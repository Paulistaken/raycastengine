const context = document.querySelector("canvas").getContext("2d");
var canvas = document.querySelector('canvas');
let framcecount = 1;
context.canvas.height = 700;
context.canvas.width = 1000;
let debug = false;
var havePointerLock = 'pointerLockElement' in window ||
    'mozPointerLockElement' in window ||
    'webkitPointerLockElement' in window;

const nextFrame = () => {
    framcecount++;
};
function calculateangle(angle, speed){
    var pi = Math.PI;
    dirx = Math.cos(angle*(pi/180));
    diry = Math.sin(angle*(pi/180));
    return([dirx*speed, diry*speed]);
};
function componentToHex(c) {
    var hex = c.toString(16);
    return hex.length == 1 ? "0" + hex : hex;
};
function rgbToHex(r, g, b) {
    return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
};
function wallcoll(){
    if(map[Math.floor((playerclass.y+50)/100)][Math.floor((playerclass.x+50)/100)] == 1 || map[Math.floor((playerclass.y)/100)][Math.floor((playerclass.x)/100)] == 1 || map[Math.floor((playerclass.y)/100)][Math.floor((playerclass.x+50)/100)] == 1 || map[Math.floor((playerclass.y+50)/100)][Math.floor((playerclass.x)/100)] == 1){
        return true
    }
    return false
};
const playerclass = {
    height: 50,
    width: 50,
    x: 200,
    y: 200,
    movestate: false,
    z: 0,
    speed: 3,
    zrot: 0,
    rot: 0,
    dirx: 0,
    diry: 0,
    jumped: false,
    velovityy: 0,
    jumppos: 0,
    jumpdelay: 0,
    gunanimstate: 0,
    shootdelay: 0,
};
let map = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1], [1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1], [1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1], [1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1], [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1], [1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1], [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1], [1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1], [1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1], [1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1], [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]];
let colormap = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1], [1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1], [1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1], [1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1], [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1], [1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1], [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1], [1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1], [1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1], [1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1], [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]];
const makelevel = function(){
    for(let y = 0; y <= map.length - 1; y++){
        for(let x = 0; x <= map[y].length - 1; x++){
            colormap[y][x] = [Math.round((Math.random() * (255 - 0))),Math.round((Math.random() * (255 - 0))),Math.round((Math.random() * (255 - 0)))];
        }
    }
};
const controller = {

  left: false,
  right: false,
  up: false,
  down: false,
  map: false,
  rleft: false,
  rright: false,
  rdown: false,
  rup: false,
  space: false,
  mouse: false,
  mouselistener: function (event){
      var key_state = (event.type == "keydown") ? true : false;
      switch (event.which){
          case 0:
            controller.mouse = key_state;
          case 1:
            controller.mouse = key_state;
          case 2:
            controller.mouse = key_state;
          case 3:
            controller.mouse = key_state;
      }
  },
  keyListener: function (event) {

    var key_state = (event.type == "keydown") ? true : false;

    switch (event.keyCode) {
      case 77:
          controller.map = key_state;
          break;
      case 65:// left key
        controller.left = key_state;
        break;
      case 83:// up key
        controller.up = key_state;
        break;
      case 68:// right key
        controller.right = key_state;
        break;
      case 87:// right key
        controller.down = key_state;
        break;
      case 74:
        controller.rleft = key_state;
        break;
      case 76:
        controller.rright = key_state;
        break;
      case 73:
         controller.rup = key_state;
        break;
      case 75:
        controller.rdown = key_state;
        break;
      case 32:
        controller.space = key_state;
        break;
    }

  },
};
let lasmpx = 0;
let mpx = 0;
const loop = function(){  
    nextFrame();
    dirs = calculateangle(playerclass.rot, playerclass.speed);
    playerclass.dirx = dirs[0];
    playerclass.diry = dirs[1];
    moving = false
    if(controller.up || controller.mouse){
        dirs = calculateangle(playerclass.rot, playerclass.speed);
        playerclass.x -= dirs[0];
        if(wallcoll() == true){
            playerclass.x += dirs[0];
        }
        playerclass.y -= dirs[1];
        if(wallcoll() == true){
            playerclass.y += dirs[1];
        }
        moving = true
    }
    if(controller.down){
        dirs = calculateangle(playerclass.rot, playerclass.speed);
        playerclass.x += dirs[0];
        if(wallcoll() == true){
            playerclass.x -= dirs[0];
        }
        playerclass.y += dirs[1];
        if(wallcoll() == true){
            playerclass.y -= dirs[1];
        }
        moving = true
    }
    if(controller.right){
        dirs = calculateangle(playerclass.rot-90, playerclass.speed);
        playerclass.x += dirs[0];
        if(wallcoll() == true){
            playerclass.x -= dirs[0];
        }
        playerclass.y += dirs[1];
        if(wallcoll() == true){
            playerclass.y -= dirs[1];
        }
        moving = true
    }
    if(controller.left){
        dirs = calculateangle(playerclass.rot+90, playerclass.speed);
        playerclass.x += dirs[0];
        if(wallcoll() == true){
            playerclass.x -= dirs[0];
        }
        playerclass.y += dirs[1];
        if(wallcoll() == true){
            playerclass.y -= dirs[1];
        }
        moving = true
    }
    if(moving){
        if(playerclass.movestate){
            playerclass.z += 1;
            if(playerclass.z > 8){
                playerclass.movestate = false;
            }
        }else{
            playerclass.z -= 1;
            if(playerclass.z < -8){
                playerclass.movestate = true;
            }
        }
    }else{
        if(playerclass.z > 0){
            playerclass.z -= 1;
        }
        if(playerclass.z < 0){
            playerclass.z += 1;
        }
    }
    if(controller.rleft){
        playerclass.rot += 4;
    }
    if(controller.rright){
        playerclass.rot -= 4;
    }
    if(playerclass.zrot > 400){
        playerclass.zrot = 400;
    }
    if(playerclass.zrot < -400){
        playerclass.zrot = -400;
    }
    if(controller.space){
        if(playerclass.jumped == false && playerclass.jumpdelay <= 0){
            playerclass.jumped = true;
            playerclass.velovityy = 2500;
            playerclass.jumpdelay = 45;
        }        
    }
    playerclass.jumpdelay -= 1;
    if(playerclass.jumppos > 16000){
        playerclass.jumppos = 16000;
        playerclass.velovityy = 0;
    }
    playerclass.jumppos += playerclass.velovityy;
    if(playerclass.jumppos > 0){
        playerclass.velovityy -= 351;
    }else{
        if(playerclass.jumped == true){
            playerclass.z = -20;
        }
        playerclass.velovityy = 0;
        playerclass.jumppos = 0;
        playerclass.jumped = false;
    }
    context.fillStyle = "#3b3b3b";
    context.fillRect(0,350+playerclass.zrot,1000,1400);
    context.fillStyle = "#212121";
    context.fillRect(0,-1050+playerclass.zrot,1000,1400);
    posses = []
    for(let x = 0; x <= 100; x++){
        const raypos = {
            x: 325,
            y: 325,
        };
        raypos.x = playerclass.x + 25;
        raypos.y = playerclass.y + 25;
        dirs = calculateangle(playerclass.rot - x + 50, 2);
        cando = true;
        for(let i = 1; i <= 800; i++){
            if(cando == true){
                raypos.x += dirs[0];
                raypos.y += dirs[1];
                if(Math.floor(raypos.y/100) >= 0 && Math.floor(raypos.y/100) < map.length && Math.floor(raypos.x/100) >= 0 && Math.floor(raypos.x/100) < map.length){
                    if(map[Math.floor(raypos.y/100)][Math.floor(raypos.x/100)] == 1){
                        cando = false;
                        sizey = (35000/i);
                        clmp = colormap[Math.floor(raypos.y/100)][Math.floor(raypos.x/100)];
                        color = [Math.floor(clmp[0]/(i/15)), Math.floor(clmp[1]/(i/15)), Math.floor(clmp[2]/(i/15))];
                        newcolor = rgbToHex(color[0], color[1], color[2]);
                        context.fillStyle = newcolor;
                        context.fillRect(x*10, 350-(sizey/2)+playerclass.z+playerclass.zrot+(playerclass.jumppos/i), 10, sizey);
                    }
                }
                if(controller.map || debug){
                    posses.push([raypos.x-5-playerclass.x+325, raypos.y-5-playerclass.y+325, 10, 10])
                }
            }
        }
    }
    gunsprites = new Image();
    gunsprites.src = "https://img.itch.zone/aW1nLzcwOTYwODMucG5n/original/um3XLF.png";
    context.drawImage(gunsprites, -(playerclass.gunanimstate*1000), playerclass.z, 13000, 700);
    
    for(let y = 0; y <= map.length - 1; y++){
        for(let x = 0; x <= map[y].length - 1; x++){
            if(map[y][x] == 1 && controller.map){
                context.fillStyle = "#ffffff";
                context.fillRect((x*100) - playerclass.x+325, (y*100) - playerclass.y+325, 100, 100);
            }
        }
    }

    for(let i = 0; i <= posses.length - 1; i++){
        context.fillStyle = "#ff0000";
        context.fillRect(posses[i][0],posses[i][1],posses[i][2],posses[i][3]);
    }

    if(controller.map || debug){
        context.fillStyle = "#ffffff";
        context.fillRect(325, 325, playerclass.width, playerclass.height);
    }

    context.fillStyle = "#ffffff";
    window.requestAnimationFrame(loop);
};

canvas.requestPointerLock = canvas.requestPointerLock ||
                            canvas.mozRequestPointerLock;

document.exitPointerLock = document.exitPointerLock ||
                           document.mozExitPointerLock;

canvas.onclick = function() {
  canvas.requestPointerLock();
};

document.addEventListener('pointerlockchange', lockChangeAlert, false);
document.addEventListener('mozpointerlockchange', lockChangeAlert, false);

function lockChangeAlert() {
    if (document.pointerLockElement === canvas ||
        document.mozPointerLockElement === canvas) {
      document.addEventListener("mousemove", updatePosition, false);
    } else {
      document.removeEventListener("mousemove", updatePosition, false);
    }
};
  
var tracker = document.getElementById('tracker');

var animation;
let mpy = 0;
let lmpy = 0;
function updatePosition(e) {
    mpx += e.movementX;
    mpy += e.movementY;
    tracker.textContent = "X position: " + mpx + ", Last xpos: " + lasmpx;
    playerclass.rot += (lasmpx - mpx) * 0.1;
    playerclass.zrot += (lmpy - mpy) * 0.8;
    if(mpx > 1000){
        mpx = 0;
    }
    if(mpx < 0){
        mpx = 1000;
    }
    lmpy = mpy;
    lasmpx = mpx;
};

window.addEventListener("mouseup", controller.mouselistener);
window.addEventListener("mousedown", controller.mouselistener);
window.addEventListener("keydown", controller.keyListener)
window.addEventListener("keyup", controller.keyListener);
window.addEventListener('mousemove', controller.mousechecker);
window.requestAnimationFrame(makelevel);
window.requestAnimationFrame(loop);